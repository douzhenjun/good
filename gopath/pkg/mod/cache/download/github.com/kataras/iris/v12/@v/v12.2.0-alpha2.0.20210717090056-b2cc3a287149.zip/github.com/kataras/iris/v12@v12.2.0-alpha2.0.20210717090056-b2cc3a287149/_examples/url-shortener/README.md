## A URL Shortener Service using Go, Iris and Bolt

Hackernoon Article: https://medium.com/hackernoon/a-url-shortener-service-using-go-iris-and-bolt-4182f0b00ae7