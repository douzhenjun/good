# Benchmarks

- [HTTP/2 Benchmarks](https://github.com/kataras/server-benchmarks#benchmarks)
- [View Engine Benchmarks](./view)
