// Package examples demonstrates httpexpect usage.
package examples
