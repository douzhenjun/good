---
name: Feature Request
about: Request a feature for the NATS Go library
labels: feature
---

## Feature Request

#### Use Case:

#### Proposed Change:

#### Who Benefits From The Change(s)?

#### Alternative Approaches

