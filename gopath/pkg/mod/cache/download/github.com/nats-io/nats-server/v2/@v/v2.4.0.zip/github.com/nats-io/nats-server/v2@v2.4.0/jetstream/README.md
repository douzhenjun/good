# JetStream (Technical Preview)

JetStream is the [NATS.io](https://nats.io) persistence engine that will support streaming as well as traditional message and worker queues for At-Least-Once delivery semantics.

More information about testing the JetStream Technical Preview can be found [here](https://github.com/nats-io/jetstream#readme)
