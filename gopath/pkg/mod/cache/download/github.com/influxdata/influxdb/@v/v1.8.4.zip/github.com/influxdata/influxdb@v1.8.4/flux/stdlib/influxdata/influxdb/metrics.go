package influxdb

// Storage metrics are not implemented in the 1.x flux engine.
