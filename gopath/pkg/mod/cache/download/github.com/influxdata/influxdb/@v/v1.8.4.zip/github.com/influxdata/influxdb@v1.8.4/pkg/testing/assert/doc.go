/*
Package assert provides helper functions that can be used with the standard Go testing package.
*/
package assert
